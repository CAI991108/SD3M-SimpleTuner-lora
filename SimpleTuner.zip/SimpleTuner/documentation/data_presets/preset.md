# Dataset Name

## Details

- **Hub link**: ...
- **Description**: ...
- **Caption format(s)**: ...

## (optional) Required preprocessing steps

If your dataset requires any steps to prepare it for use in SimpleTuner, those should be listed here, along with any code snippets that would help.

## Dataloader configuration example

Here, you'll place the `multidatabackend.json` contents that will work for this dataset.

```json
...
```
